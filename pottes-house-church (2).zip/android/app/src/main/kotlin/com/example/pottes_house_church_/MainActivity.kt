package com.example.pottes_house_church_

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
